﻿using BookManagement.DAL.Models;
using BookManagement.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManagement.BLL.Services
{
    public class BookService
    {
        private BookRepository _repo = new();
        public List<Book> GetAll()
        {
            return _repo.GetAll();
        }
        public List<Book> SearchByNameOrDescription(string name, string description)
        {
            return _repo.SearchByNameOrDescription(name, description);
        }
        public void Add(Book x)
        {
            _repo.Add(x);
        }
        public void Delete(Book x)
        {
            _repo.Delete(x);
        }
        public void Update(Book x)
        {
            _repo.Update(x);
        }
    }
}
