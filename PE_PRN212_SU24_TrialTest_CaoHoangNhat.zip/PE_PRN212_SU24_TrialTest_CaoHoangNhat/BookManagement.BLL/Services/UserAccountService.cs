﻿using BookManagement.DAL.Models;
using BookManagement.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManagement.BLL.Services
{
    public class UserAccountService
    {
        private UserAccountRepository _repo = new();
        public UserAccount? GetUser(string email, string password)
        {
            return _repo.GetUser(email, password);
        }
    }
}
