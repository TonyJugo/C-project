﻿using BookManagement.BLL.Services;
using BookManagement.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BookManagement_CaoHoangNhat
{
    /// <summary>
    /// Interaction logic for DetailWindow.xaml
    /// </summary>
    public partial class DetailWindow : Window
    {
        public Book? EditOne {  get; set; }
        private BookCategoryService categoryService = new();
        private BookService bookService = new();
        public DetailWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!Validate())
            {
                return;
            }
            if(EditOne == null)
            {
                Book x = new();
                x.BookName = BookNameTextBox.Text;
                x.Description = DescriptionTextBox.Text;
                x.Author = AuthorTextBox.Text;
                x.Price = double.Parse(PriceTextBox.Text);
                x.Quantity = int.Parse(QuantityTextBox.Text);
                x.PublicationDate = (DateTime)PublicationDateDatePicker.SelectedDate;
                x.BookCategoryId = (int)BookCategoryIdComboBox.SelectedValue;
                bookService.Add(x);
            }
            else
            {
                EditOne.BookName = BookNameTextBox.Text;
                EditOne.Description = DescriptionTextBox.Text;
                EditOne.Author = AuthorTextBox.Text;
                EditOne.Price = double.Parse(PriceTextBox.Text);
                EditOne.Quantity = int.Parse(QuantityTextBox.Text);
                EditOne.PublicationDate = (DateTime)PublicationDateDatePicker.SelectedDate;
                EditOne.BookCategoryId = (int)BookCategoryIdComboBox.SelectedValue;
                bookService.Update(EditOne);
            }
            this.Close();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private bool Validate()
        {
            //DetailMode.Content = "Update";
            //BookIdTextBox.Text = EditOne.BookId.ToString();
            //BookIdTextBox.IsEnabled = false;
            //BookNameTextBox.Text = EditOne.BookName;
            //DescriptionTextBox.Text = EditOne.Description;
            //PublicationDateDatePicker.SelectedDate = EditOne.PublicationDate;
            //QuantityTextBox.Text = EditOne.Quantity.ToString();
            //PriceTextBox.Text = EditOne.Price.ToString();
            //AuthorTextBox.Text = EditOne.Author;
            //BookCategoryIdComboBox.SelectedItem = EditOne.BookCategoryId;
            if (string.IsNullOrWhiteSpace(BookNameTextBox.Text))
            {
                MessageBox.Show("Name missing", "Name required", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            if(BookNameTextBox.Text.Trim().Length <5 || BookNameTextBox.Text.Trim().Length > 90)
            {
                MessageBox.Show("Name length in 5 to 90", "Name length invalid", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            string[] name = BookNameTextBox.Text.Trim().Split(' ');
            foreach (var word in name)
            {
                if (!Regex.IsMatch(word, "^[A-Z]"))
                {
                    MessageBox.Show("each word in name must start with capitalized letter ", "Invalid naming convention", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }
            if (string.IsNullOrWhiteSpace(DescriptionTextBox.Text))
            {
                MessageBox.Show("Description missing", "Description required", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            if (PublicationDateDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Date missing", "Date required", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            if (string.IsNullOrWhiteSpace(QuantityTextBox.Text))
            {
                MessageBox.Show("Quantity missing", "Quantity required", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            int quantity;
            bool quantityStatus = int.TryParse(QuantityTextBox.Text, out quantity);
            if(!quantityStatus)
            {
                MessageBox.Show("Quantity is a int number", "Quantity invalid type", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            if(quantity < 0 || quantity >= 4000000)
            {
                MessageBox.Show("Quantity is greater than or equal to 0 and less than 4 000 000", "Quantity invalid range", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            if (string.IsNullOrWhiteSpace(PriceTextBox.Text))
            {
                MessageBox.Show("Price missing", "Price required", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            double price;
            bool priceStatus = double.TryParse(PriceTextBox.Text, out price);
            if (!priceStatus)
            {
                MessageBox.Show("Price is a double number", "Price invalid type", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            if (price < 0 || price >= 4000000)
            {
                MessageBox.Show("Price is greater than or equal to 0 and less than 4 000 000", "Price invalid range", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            if (string.IsNullOrWhiteSpace(AuthorTextBox.Text))
            {
                MessageBox.Show("Author missing", "Author required", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            if (BookCategoryIdComboBox.SelectedItem == null)
            {
                MessageBox.Show("Book Genre missing", "Book Genre required", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            return true;
        }
        private void FillComboBox()
        {   
            BookCategoryIdComboBox.ItemsSource = categoryService.GetAll().ToList();
            BookCategoryIdComboBox.SelectedValuePath = "BookCategoryId";
            BookCategoryIdComboBox.DisplayMemberPath = "BookGenreType";
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            FillComboBox();
            if (EditOne == null)
            {
                DetailMode.Content = "Create";
                BookIdTextBox.IsEnabled = false;
            }
            else
            {
                DetailMode.Content = "Update";
                BookIdTextBox.Text = EditOne.BookId.ToString();
                BookIdTextBox.IsEnabled = false;
                BookNameTextBox.Text = EditOne.BookName;
                DescriptionTextBox.Text = EditOne.Description;
                PublicationDateDatePicker.SelectedDate = EditOne.PublicationDate;
                QuantityTextBox.Text = EditOne.Quantity.ToString();
                PriceTextBox.Text = EditOne.Price.ToString();
                AuthorTextBox.Text = EditOne.Author;
                BookCategoryIdComboBox.SelectedValue = EditOne.BookCategoryId;
            }
        }
    }
}
