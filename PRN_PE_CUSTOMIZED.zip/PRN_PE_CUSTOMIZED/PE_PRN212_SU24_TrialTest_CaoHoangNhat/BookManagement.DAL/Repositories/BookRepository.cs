﻿using BookManagement.DAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManagement.DAL.Repositories
{
    public class BookRepository
    {
        private BookManagementDbContext _context;
        public List<Book> GetAll()
        {
            _context = new();
            return _context.Books.Include("BookCategory").ToList();
        }
        public List<Book> SearchByNameOrDescription(string name, string description)
        {
            List<Book> result = GetAll();
            _context = new();
            //nếu có name và description
            if(!string.IsNullOrWhiteSpace(name) && !string.IsNullOrWhiteSpace(description)){
                result = result.Where(x => x.BookName.ToLower().Contains(name) || x.Description.ToLower().Contains(description)).ToList();
                return result;
            }
            //nếu có name
            if (!string.IsNullOrEmpty(name))
            {
                result = result.Where(x => x.BookName.ToLower().Contains(name)).ToList();
                return result;
            }
            //nếu có description
            if (!string.IsNullOrEmpty(description))
            {
                result = result.Where(x => x.Description.ToLower().Contains(description)).ToList();
                return result;
            }
            return result;
        }
        public void Add(Book x)
        {
            _context = new();
            _context.Books.Add(x);
            _context.SaveChanges();
        }
        public void Update(Book x)
        {
            _context = new();
            _context.Books.Update(x);
            _context.SaveChanges();
        }
        public void Delete(Book x)
        {
            _context = new();
            _context.Books.Remove(x);
            _context.SaveChanges();
        }
    }
}
