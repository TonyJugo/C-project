﻿using BookManagement.BLL.Services;
using BookManagement.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BookManagement_CaoHoangNhat
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        private UserAccountService _service = new();

        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            if(string.IsNullOrWhiteSpace(EmailTextBox.Text) && string.IsNullOrWhiteSpace(PasswordTextBox.Text))
            {
                MessageBox.Show("Credentials missing","Credentials required", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            UserAccount? user = _service.GetUser(EmailTextBox.Text, PasswordTextBox.Text);
            if(user == null)
            {
                MessageBox.Show("Credentials Wrong", "Wrong", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if(user.Role == 3)
            {
                MessageBox.Show("You have no permission to access this function!", "No permission", MessageBoxButton.OK,MessageBoxImage.Error);
                return;
            }
            MainWindow m = new();
            m.User = user;
            m.Show();
            this.Hide();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
