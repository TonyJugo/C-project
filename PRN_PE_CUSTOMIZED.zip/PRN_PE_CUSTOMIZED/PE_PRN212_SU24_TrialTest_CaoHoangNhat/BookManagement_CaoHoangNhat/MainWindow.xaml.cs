﻿using BookManagement.BLL.Services;
using BookManagement.DAL.Models;
using BookManagement.DAL.Repositories;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BookManagement_CaoHoangNhat
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public UserAccount User {  get; set; }
        private BookService bookService = new();

        
        public MainWindow()
        {
            InitializeComponent();
        }



        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            Book? editOne = BookListDataGrid.SelectedItem as Book;
            if (editOne == null)
            {
                MessageBox.Show("Select one", "No Selection", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            DetailWindow d = new();
            d.EditOne = editOne;
            d.ShowDialog();
            BookListDataGrid.ItemsSource = null;
            BookListDataGrid.ItemsSource = bookService.GetAll();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            Book? editOne = BookListDataGrid.SelectedItem as Book;
            if (editOne == null)
            {
                MessageBox.Show("Select one", "No Selection", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            var result = MessageBox.Show("Are you sure ?","Caution", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                bookService.Delete(editOne);
                BookListDataGrid.ItemsSource = null;
                BookListDataGrid.ItemsSource = bookService.GetAll();
            }
        }

        private void QuitButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if(User.Role == 2)
            {
                CreateButton.IsEnabled = false;
                DeleteButton.IsEnabled = false;
                UpdateButton.IsEnabled = false;
            }
            BookListDataGrid.ItemsSource = null;
            BookListDataGrid.ItemsSource = bookService.GetAll();

        }
        
        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            DetailWindow d = new();
            d.ShowDialog();
            BookListDataGrid.ItemsSource = null;
            BookListDataGrid.ItemsSource = bookService.GetAll();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            var result = bookService.SearchByNameOrDescription(BookNameTextBox.Text.ToLower().Trim(), DescriptionTextBox.Text.ToLower().Trim());
            BookListDataGrid.ItemsSource = null; 
            BookListDataGrid.ItemsSource = result;
        }
    }
}